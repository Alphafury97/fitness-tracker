import React from "react";

function App() {
  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>Fitness Tracker App</h1>
      <p>Benvenuto! Qui potrai tracciare la tua dieta, allenamento e progressi.</p>
    </div>
  );
}

export default App;